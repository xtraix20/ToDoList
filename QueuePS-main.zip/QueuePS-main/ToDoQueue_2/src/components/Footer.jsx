import '../styles/Footer.sass'

const Footer=()=>{
    return(
        <>
            <div className='master2'>
                <div className="barra">
                    <h1> ‎</h1>
                </div>
                <div className="contenedor">
                <div className="obj1">
                    <p>Copyright © 2024 XFLAT Company S.L. Todos los derechos reservados.</p>
                    </div>
                <div className="obj2">
                    <p>Creado por: Felipe Guerrero</p>
                </div>
                 </div>
            
            </div> 
            
        </>
    )
}

export default Footer